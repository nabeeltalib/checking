import React from 'react'

const Collaborative = () => {
  return (
    <div>Collaborative</div>
  )
}

export default Collaborative