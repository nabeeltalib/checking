// src/components/shared/notifications/index.ts

export { NotificationBell } from './NotificationBell';
export { NotificationsList } from './NotificationsList';